from __future__ import annotations

import argparse
from math import sqrt
from pathlib import Path

import numpy as np

import pymembrane as mb
from ._resources import example_data_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Periodic membrane example")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--snapshots", type=int, default=None)
    parser.add_argument("--run_steps", type=int, default=None)
    parser.add_argument("--epsilon", type=float, default=0.01)
    args = parser.parse_args()

    snapshots = args.snapshots if args.snapshots is not None else (3 if args.quick else 100)
    run_steps = args.run_steps if args.run_steps is not None else (10 if args.quick else 5000)

    with example_data_path("02_periodic/vertices.dat") as vertex_file, example_data_path("02_periodic/faces.dat") as face_file:
        box = mb.Box(sqrt(3.0) * 29, 50.0, 50.0, True, True, True)
        system = mb.System(box)
        system.read_mesh_from_files(files={"vertices": str(vertex_file), "faces": str(face_file)})
        system.enforce_boundaries()
        dump = system.dumper
        dump.vtk(filename="initial_mesh", periodic=True)

        evolver = mb.Evolver(system)
        evolver.add_force("Mesh>Harmonic", {"k": {"0": "100.0"}, "l0": {"0": "1.0"}})
        evolver.add_force("Mesh>Limit", {"lmin": {"0": "0.7"}, "lmax": {"0": "1.3"}})
        evolver.add_force("Mesh>Bending>Dihedral", {"kappa": {"0": "1.0"}})
        evolver.add_integrator("Mesh>Brownian>vertex>move", {"seed": "202208"})
        evolver.set_time_step("2e-3")
        evolver.set_global_temperature("1e-4")

        def compress_box(_epsilon: float):
            old_box = system.box
            return mb.Box(old_box.L.x * (1 - _epsilon), old_box.L.y, old_box.L.z, True, True, True)

        compute = system.compute
        print("[Initial] avg_edge_length =", np.mean(compute.edge_lengths()))
        print("[Initial] energy =", compute.energy(evolver))
        dump.vtk("periodic_t0", periodic=True)
        for snapshot in range(1, snapshots):
            evolver.evolveMD(steps=run_steps)
            dump.vtk(f"periodic_t{snapshot * run_steps}", periodic=True)
            if snapshot < 50:
                system.box = compress_box(args.epsilon)
                system.enforce_boundaries()
        print("[Final] avg_edge_length =", np.mean(compute.edge_lengths()))
        print("[Final] energy =", compute.energy(evolver))


if __name__ == "__main__":
    main()
