"""Bundled example mesh data."""
