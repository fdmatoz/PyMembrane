from __future__ import annotations

import argparse
import tempfile
import zipfile
from pathlib import Path

import numpy as np

import pymembrane as mb
from ._resources import example_data_path

try:
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    import scienceplots

    plt.style.use(["science"])
except ImportError:  # pragma: no cover - optional plotting dependency
    plt = None
    ticker = None


def _extract_mesh(n: int) -> tuple[Path, Path]:
    cache_dir = Path(tempfile.gettempdir()) / f"pymembrane_disclination_{n}"
    vertex_file = cache_dir / f"InputFiles/vertices_N{n}.inp"
    face_file = cache_dir / f"InputFiles/faces_N{n}.inp"
    if vertex_file.exists() and face_file.exists():
        return vertex_file, face_file

    cache_dir.mkdir(parents=True, exist_ok=True)
    with example_data_path("01_disclination/InputFiles.zip") as archive_path:
        with zipfile.ZipFile(archive_path) as archive:
            archive.extract(f"InputFiles/vertices_N{n}.inp", path=cache_dir)
            archive.extract(f"InputFiles/faces_N{n}.inp", path=cache_dir)
    return vertex_file, face_file


def main() -> None:
    parser = argparse.ArgumentParser(description="Disclination example")
    parser.add_argument("--mode", choices=["brownian", "mc", "verlet"], default="brownian")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--N", type=int, default=14)
    parser.add_argument("--snapshots", type=int, default=None)
    parser.add_argument("--run_steps", type=int, default=None)
    args = parser.parse_args()

    snapshots = args.snapshots if args.snapshots is not None else (3 if args.quick else 200)
    run_steps = args.run_steps if args.run_steps is not None else (10 if args.quick else 5000)
    vertex_file, face_file = _extract_mesh(args.N)

    box = mb.Box(100.0, 100.0, 100.0)
    system = mb.System(box)
    system.read_mesh_from_files(files={"vertices": str(vertex_file), "faces": str(face_file)})
    dump = system.dumper
    dump.vtk("initial mesh", False)

    evolver = mb.Evolver(system)
    evolver.add_force("Mesh>Harmonic", {"k": {"0": "100.0"}, "l0": {"0": "1.0"}})
    evolver.add_force("Mesh>Limit", {"lmin": {"0": "0.7"}, "lmax": {"0": "1.3"}})
    evolver.add_force("Mesh>Bending>Dihedral", {"kappa": {"0": "1.0"}})

    if args.mode == "brownian":
        evolver.add_integrator("Mesh>Brownian>vertex>move", {"seed": "202208"})
        evolve = lambda: evolver.evolveMD(steps=run_steps)
        schedule = [1e-4, 1e-5, 1e-6, 0.0]
        evolve_fn = lambda: [evolver.set_global_temperature(str(t)) or evolver.evolveMD(steps=run_steps) for t in schedule]
        snapshots = min(snapshots, 4 if args.quick else snapshots)
    elif args.mode == "mc":
        evolver.add_integrator("Mesh>MonteCarlo>vertex>move", {"dr": "0.008"})
        evolve_fn = lambda: [evolver.set_global_temperature(str(t)) or evolver.evolveMC(steps=run_steps) for t in [1e-3, 1e-5, 1e-7, 0.0]]
        snapshots = min(snapshots, 4 if args.quick else snapshots)
    else:
        evolver.add_integrator("Mesh>VelocityVerlet>vertex>move", {"limit": "True", "limit_val": "0.008"})
        vertices = system.vertices
        for vertex in vertices:
            vertex.mass = 1.0
        system.vertices = vertices
        evolve_fn = lambda: evolver.evolveMD(steps=run_steps)

    compute = system.compute
    print("[Initial] avg_edge_length =", np.mean(compute.edge_lengths()))
    print("[Initial] energy =", compute.energy(evolver))
    dump.vtk("disclination_t0")
    for snapshot in range(1, snapshots):
        evolve_fn()
        dump.vtk("disclination_t" + str(snapshot * run_steps))

    if plt is not None and args.mode == "mc":
        mc_energy = [100.0 * compute.energy(evolver)["edges"] / system.Numedges]
        fig, ax = plt.subplots(figsize=(3.3, 3.3))
        ax.plot(mc_energy, "o-")
        ax.set_xlabel(r"$MC steps$", fontsize=10, labelpad=2.5)
        ax.set_ylabel(r"$Energy/NumEdges \times 10^{-2}$", fontsize=11, labelpad=2.5)
        ax.tick_params(axis="x", labelsize=8, pad=4)
        ax.tick_params(axis="y", labelsize=8, pad=4)
        ax.ticklabel_format(useMathText=True)
        ax.xaxis.set_major_formatter(ticker.ScalarFormatter())
        ax.yaxis.set_major_formatter(ticker.ScalarFormatter())
        plt.tight_layout()
        plt.savefig("energy.svg", dpi=400)


if __name__ == "__main__":
    main()
