from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

import pymembrane as mb
from ._resources import example_data_path

try:
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    import scienceplots

    plt.style.use(["science"])
except ImportError:  # pragma: no cover - optional plotting dependency
    plt = None
    ticker = None


def main() -> None:
    parser = argparse.ArgumentParser(description="Caspar-Klug sphere buckling example")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--snapshots", type=int, default=None)
    parser.add_argument("--run_steps", type=int, default=None)
    args = parser.parse_args()

    snapshots = args.snapshots if args.snapshots is not None else (3 if args.quick else 100)
    run_steps = args.run_steps if args.run_steps is not None else (10 if args.quick else 5000)

    with example_data_path("03_Caspar-Klug_sphere/vertices.dat") as vertex_file, example_data_path("03_Caspar-Klug_sphere/faces.dat") as face_file:
        system = mb.System(mb.Box(4, 4, 4))
        system.read_mesh_from_files(files={"vertices": str(vertex_file), "faces": str(face_file)})
        dump = system.dumper
        dump.vtk("initial mesh", False)

        evolver = mb.Evolver(system)
        evolver.add_force("Mesh>Harmonic", {"k": {"0": "350.0"}, "l0": {"0": "1.0"}})
        evolver.add_force("Mesh>Limit", {"lmin": {"0": "0.7"}, "lmax": {"0": "1.3"}})
        evolver.add_force("Mesh>Bending>Dihedral", {"kappa": {"0": "1.0"}})
        evolver.add_integrator("Mesh>MonteCarlo>vertex>move", {"dr": "0.008"})

        compute = system.compute
        mc_energy = [None] * snapshots
        mc_energy[0] = 100.0 * compute.energy(evolver)["edges"] / system.Numedges
        print("[Initial] energy = {} x 10^-2".format(mc_energy[0]))
        dump.vtk("sphere_t0")
        for snapshot in range(1, snapshots):
            for temperature in [1e-3, 1e-5, 1e-7, 0.0]:
                evolver.set_global_temperature(str(temperature))
                evolver.evolveMC(steps=run_steps)
            dump.vtk("sphere_t" + str(snapshot * run_steps))
            mc_energy[snapshot] = 100.0 * compute.energy(evolver)["edges"] / system.Numedges
            print("[{}] energy = {} x 10^-2".format(snapshot, mc_energy[snapshot]))

        if plt is not None:
            fig, ax = plt.subplots(figsize=(3.3, 3.3))
            ax.plot(mc_energy, "o-")
            ax.set_xlabel(r"$MC steps$", fontsize=10, labelpad=2.5)
            ax.set_ylabel(r"$Energy/NumEdges \times 10^{-2}$", fontsize=11, labelpad=2.5)
            ax.tick_params(axis="x", labelsize=8, pad=4)
            ax.tick_params(axis="y", labelsize=8, pad=4)
            ax.ticklabel_format(useMathText=True)
            ax.xaxis.set_major_formatter(ticker.ScalarFormatter())
            ax.yaxis.set_major_formatter(ticker.ScalarFormatter())
            plt.tight_layout()
            plt.savefig("energy.svg", dpi=400)


if __name__ == "__main__":
    main()
