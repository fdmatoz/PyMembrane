from __future__ import annotations

import argparse

import numpy as np

import pymembrane as mb
from ._resources import example_data_path

try:
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    import scienceplots

    plt.style.use(["science"])
except ImportError:  # pragma: no cover - optional plotting dependency
    plt = None
    ticker = None


def main() -> None:
    parser = argparse.ArgumentParser(description="Energy minimization example")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--snapshots", type=int, default=None)
    parser.add_argument("--max_iter", type=int, default=None)
    args = parser.parse_args()

    snapshots = args.snapshots if args.snapshots is not None else (2 if args.quick else 50)
    max_iter = args.max_iter if args.max_iter is not None else (25 if args.quick else 2000)

    with example_data_path("04_minimization/vertices_R1.0_l01.inp") as vertex_file, example_data_path("04_minimization/faces_R1.0_l01.inp") as face_file:
        system = mb.System(mb.Box(40, 40, 40))
        system.read_mesh_from_files(files={"vertices": str(vertex_file), "faces": str(face_file)})
        dump = system.dumper
        dump.vtk("initial mesh", False)

        evolver = mb.Evolver(system)
        compute = system.compute
        edge_lengths = compute.edge_lengths()
        avg_edge_length = np.mean(edge_lengths)
        print("[Initial] avg_edge_length =", avg_edge_length)

        evolver.add_force("Mesh>Harmonic", {"k": {"0": "400.0"}, "l0": {"0": str(1.1 * avg_edge_length)}})
        evolver.add_force("Mesh>Limit", {"lmin": {"0": str(0.5 * np.min(edge_lengths))}, "lmax": {"0": str(2.0 * np.max(edge_lengths))}})
        evolver.add_force("Mesh>Bending>Dihedral", {"kappa": {"0": "1.0"}})
        evolver.add_minimizer("Mesh>Fire", {"dt": "1e-2", "max_iter": str(max_iter), "ftol": "1e-2", "etol": "1e-4"})
        evolver.add_constraint("Mesh>Volume", {"V": str(compute.volume()), "max_iter": "10000", "tol": "1e-5"})

        vertices = system.vertices
        rnd_move = 0.5 * np.std(edge_lengths) / 6.0
        for vertex in vertices:
            vertex.r.x += np.random.uniform(-rnd_move, rnd_move)
            vertex.r.y += np.random.uniform(-rnd_move, rnd_move)
            vertex.r.z += np.random.uniform(-rnd_move, rnd_move)
        system.vertices = vertices

        min_energy = [None] * snapshots
        min_energy[0] = 100.0 * compute.energy(evolver)["edges"] / system.Numedges
        print("[Initial] energy:{} x 10^-2 volume:{}".format(min_energy[0], compute.volume()))
        dump.vtk("minimization_t0")
        for snapshot in range(1, snapshots):
            evolver.minimize()
            dump.vtk("minimization_t{}".format(snapshot))
            min_energy[snapshot] = 100.0 * compute.energy(evolver)["edges"] / system.Numedges
            print("[{}] energy:{} x 10^-2 volume:{}".format(snapshot, min_energy[snapshot], compute.volume()))

        if plt is not None:
            fig, ax = plt.subplots(figsize=(3.3, 3.3))
            ax.plot(min_energy, "o-")
            ax.set_xlabel(r"$Steps$", fontsize=10, labelpad=2.5)
            ax.set_ylabel(r"$Energy/NumEdges \times 10^{-2}$", fontsize=11, labelpad=2.5)
            ax.tick_params(axis="x", labelsize=8, pad=4)
            ax.tick_params(axis="y", labelsize=8, pad=4)
            ax.ticklabel_format(useMathText=True)
            ax.xaxis.set_major_formatter(ticker.ScalarFormatter())
            ax.yaxis.set_major_formatter(ticker.ScalarFormatter())
            plt.tight_layout()
            plt.savefig("energy.svg", dpi=400)


if __name__ == "__main__":
    main()
